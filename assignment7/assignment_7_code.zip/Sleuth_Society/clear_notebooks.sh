#!/bin/bash
jupyter nbconvert --ClearOutputPreprocessor.enabled=True --clear-output break_hash.ipynb

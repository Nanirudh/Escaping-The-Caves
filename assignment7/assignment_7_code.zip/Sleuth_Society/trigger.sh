#!/bin/bash
jupyter-nbconvert break_hash.ipynb --to python
chmod +x break_hash.py
python3 break_hash.py

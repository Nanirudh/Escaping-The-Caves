*****************************************IMPORTANT INSTRUCTIONS**************************************
*****************************************************************************************************

1.To run the code please give the command 'make attack'
2. make file calls trigger.sh shell script
3. trigger.sh calls 
   3.1 clears the ouput of notebooks hexadecimal_clues.ipynb, break_rsa.ipynb
   3.2 creates hexadecimal_clues.py, break_rsa.py python files
   3.3 runs the python files
   
4. hexadecimal_clues.ipynb decodes the hexadecimal clues given at the end of the screen.
5. break_rsa.ipynb takes n,c,e as input.Takes advantage of small e and performs coppersmith's attack.Creates another polynomial with same plaintext roots and finds the roots.

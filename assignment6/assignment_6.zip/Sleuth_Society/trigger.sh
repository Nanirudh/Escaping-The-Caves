#!/bin/bash

jupyter nbconvert --ClearOutputPreprocessor.enabled=True --clear-output hexadecimal_clues.ipynb
jupyter nbconvert --ClearOutputPreprocessor.enabled=True --clear-output break_rsa.ipynb

jupyter-nbconvert hexadecimal_clues.ipynb --to python
chmod +x hexadecimal_clues.py
python3 hexadecimal_clues.py

jupyter-nbconvert break_rsa.ipynb --to python
chmod +x break_rsa.py
python3 break_rsa.py


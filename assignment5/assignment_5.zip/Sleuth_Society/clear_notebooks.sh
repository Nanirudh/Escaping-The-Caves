#!/bin/bash
jupyter nbconvert --ClearOutputPreprocessor.enabled=True --clear-output key_gen.ipynb
jupyter nbconvert --ClearOutputPreprocessor.enabled=True --clear-output output_extraction.ipynb
jupyter nbconvert --ClearOutputPreprocessor.enabled=True --clear-output pass.ipynb
jupyter nbconvert --ClearOutputPreprocessor.enabled=True --clear-output plaintext_gen.ipynb

#!/bin/bash
jupyter-nbconvert plaintext_gen.ipynb --to python
chmod +x plaintext_gen.py
python3 plaintext_gen.py

chmod +x script.exp
#./script.exp
echo "*************Please wait for two minutes******************"
gnome-terminal -e ./script.exp 

sleep 20

jupyter-nbconvert output_extraction.ipynb --to python
chmod +x output_extraction.py
python3 output_extraction.py

jupyter-nbconvert key_gen.ipynb --to python
chmod +x key_gen.py
python3 key_gen.py

jupyter-nbconvert pass.ipynb --to python
chmod +x pass.py
python3 pass.py
